% 2.13.2026
% Batch run model scaling, inverse kinematics, inverse dynamics, joint
% reactions, and body kinematics (analysis tool)
% Note: this code assumes that you have generated proper .trc and .mot
% files, from the NORAXON SYSTEM ONLY. May need to first use the
% MATLAB_fullPipeline_CSVtoTRCMOT.m code to convert Noraxon exported CSVs to usable TRC and MOT files.

% Data Structure:
    % Parent folder
        % One copy of the base, unscaled model for analysis
        % Template Scaling, IK, ID, Analysis XMLs
        % Subject subfolders
            % All subject trial .CSVs
            % subjectData.mat <-- has subjectMass, subjectName

% Code will add to each subfolder:
    % Marker coordinates [.trc] 
    % Kinematics [_ik.mot]
    % Kinematics errors [_ik_marker_errors.sto]
    % Kinetics [_ID.sto]

%% SETUP
clear
close all

import org.opensim.modeling.* % Set up proper OpenSim stuff

%% FUNCTIONS

% Read data from the Noraxon .csv files
function trial_data = readNoraxon(trial_read, trajectoriesFixed, trajectoriesOriginal, forces)
    % Read time data
    trial_data.time = table2array(trial_read(:, 'time'));
    for i = 1:length(trajectoriesOriginal) % Read virtual marker data
        trial_data.(trajectoriesFixed{i}) = table2array(trial_read(:, trajectoriesOriginal{i}));
    end
        
    for i = 1:length(forces) % Read insole data
        trial_data.(forces{i}) = table2array(trial_read(:, forces(i)));
    end
end

% Noraxon insoles offset on the x axis by 1.8" - correct for this
% Also, change NaNs to zeros, and make corresponding GRF also zero
function [fixCoPx, fixCoPy, fixGRF] = fixCoPNaNs(rawCoPx, rawCoPy, rawGRF)
    fixCoPx = rawCoPx;
    fixCoPy = rawCoPy;
    fixGRF = rawGRF;
    for t = 1:length(rawCoPx)
        if isnan(rawCoPx(t))
            fixCoPx(t) = 0;
            fixCoPy(t) = 0;
            fixGRF(t) = 0;
        else
            fixCoPx(t) = rawCoPx(t) - 50;
            fixCoPy(t) = rawCoPy(t) - 50;
        end
    end
end

% Switch y and z, then negate the new z
function rotated_data = rotateAroundX(trial_data, trajectories)
        rotated_data = trial_data;
        for i = 1:length(trajectories)
            if contains(trajectories{i}, '_y')
                markerName = erase(trajectories{i}, '_y');
                YZmarkers = {};
                YZmarkers{1} = append(markerName, '_y');
                YZmarkers{2} = append(markerName, '_z');
                tempY = trial_data.(YZmarkers{1});
                tempZ = trial_data.(YZmarkers{2});
                rotated_data.(YZmarkers{1}) = tempZ;
                rotated_data.(YZmarkers{2}) = -tempY;
            end
        end
    end


%% SELECT WORKING DIRECTORY

% Read directory of current subject
% parentDirectory = uigetdir('', 'Select the parent folder that contains all subject subfolders'); % Select parent directory
% cd(parentDirectory);
parentDirectory = cd;
a = dir(parentDirectory); b = [a.isdir]; c = a(b); d = {c.name}; 
subjectSubfoldersList = d(:, 3:end); % Get list of all subject subfolders in the parent directory
clear("a", "b", "c", "d");

%% LOAD TEMPLATE FILES

load("NoraxonTrajectoriesAndForcesAll.mat") % Loads trajectory and force names with original and fixed names
templateTRCname = fullfile(parentDirectory, "NoraxonMarkerBlank.txt");
templateMOTname = fullfile(parentDirectory, "grf_motBLANK.txt");

kinematicsTool = InverseKinematicsTool("KinematicsTemplate.xml");
kineticsTool = InverseDynamicsTool("KineticsTemplate.xml");
baseModel = Model("LFB_v2.osim");
baseModel.initSystem();

%% CREATE TRC FILES


fprintf('\nCreating .TRC files from Noraxon .CSVs...\n')
for i = 1:length(subjectSubfoldersList)
    subjectFolderAddress = fullfile(parentDirectory, subjectSubfoldersList{i}); % Set address of current subject subfolder
    cd(subjectFolderAddress); % Set current directory to this subject subfolder
    load('subjectData.mat'); % Load the subject data (name and mass)

    % Get list of all .csv trials
    a = dir('*.csv');
    subjectCSVTrials = {a.name}; clear("a");

        for j = 1:length(subjectCSVTrials) % Loop through the trials
            csvName = subjectCSVTrials{j};
            trialID = csvName(1:end-4);
            data_read = readtable(subjectCSVTrials{j});

            currentMarkerSet = {};

            trial_trc = readcell(templateTRCname);

            csvData = readNoraxon(data_read, trajectoriesFixed, trajectoriesOriginal, forces);    
            rotated_data = rotateAroundX(csvData, trajectoriesFixed);

            % Set up .trc files

            % Set up header info
            trial_trcName = append(subjectName, '_', trialID, '.trc');
            dataCount = length(rotated_data.time);

            % Add specific header info
            trial_trc{2,4} = trial_trcName;
            trial_trc{4,3} = dataCount;
            trial_trc{4,8} = dataCount;

            % Add frame, time, and marker coordinate data
            for i = 1:dataCount
                trial_trc{i+6,1} = i; % Frame#
                trial_trc{i+6,2} = i*0.002-0.002; % Time
                for k = 1:length(trajectoriesFixed) % Marker coordinate data
                    trial_trc{i+6,k+2} = rotated_data.(trajectoriesFixed{k})(i);
                end
            end

            % Remove <missing> in cells
            mask = cellfun(@(x) any(isa(x,'missing')), trial_trc);
            trial_trc(mask) = {[]}; % or whatever value you want to use

            % Write marker trc files
            trial_fileName = trial_trcName(1:end-4);
            fullfilePath = fullfile(trial_fileName);
            writecell(trial_trc(2:end,1:end), fullfilePath, 'Delimiter', '\t');

            % Change files from .txt to .trc
            file1 = append(fullfilePath, '.txt');
            file2 = strrep(file1,'.txt','.trc');
            copyfile(file1,file2);
            delete(file1);
            fprintf(['Wrote ' trial_fileName '.trc\n'])
        end
end

%% SCALING PERFORMS ONCE FOR EACH SUBJECT
% For each trial in each subject subfolder in the parent directory
for i = 1:length(subjectSubfoldersList)
% for i = length(subjectSubfoldersList)
    subjectFolderAddress = fullfile(parentDirectory, subjectSubfoldersList{i}); % Set address of current subject subfolder
    cd(subjectFolderAddress); % Set current directory to this subject subfolder
    load('subjectData.mat'); % Load the subject data (name and mass)
    
    % Get list of all .trc trials
    a = dir('*.trc');
    subjectTRCTrials = {a.name}; clear("a");

    %% SCALING
    % Couldn't get the MATLAB API calls to work properly, so this edits the
    % XML directly, saves it as a new one, and then executes it to scale
    % the model for each subject

    xmlPath = fullfile(parentDirectory, "NoraxonScaleTemplate.xml"); % Read in template XML
    xmlFile = xmlread(xmlPath);
    
    lfbAddress = fullfile(parentDirectory, "LFB_v2.osim"); % Set the base model
    xmlFile.getElementsByTagName('model_file').item(0).setTextContent(lfbAddress);

    noraxonMarkersAddress = fullfile(parentDirectory, "LFB_Noraxon_Markers.xml"); % Assign marker set
    xmlFile.getElementsByTagName('marker_set_file').item(0).setTextContent(noraxonMarkersAddress);

    trialForScale = subjectTRCTrials{1}; % Use whatever first trial as pseudostatic to scale
    % Note: for CATT participants, may want to instead use the walking
    % calibration as pseudostatic
    trialScaleAddress = fullfile(subjectFolderAddress, trialForScale);
    xmlFile.getElementsByTagName('marker_file').item(0).setTextContent(trialScaleAddress);
    xmlFile.getElementsByTagName('marker_file').item(1).setTextContent(trialScaleAddress);

    xmlFile.getElementsByTagName('mass').item(0).setTextContent(num2str(subjectMass)); % Set subject mass

    outputModelName = append(subjectName, '_scaledModel.osim'); % Set the scaled model output
    xmlFile.getElementsByTagName('output_model_file').item(0).setTextContent(outputModelName);

    scaleXMLName = [subjectName '_scaleTool.xml'];
    xmlwrite(scaleXMLName, xmlFile); % Save the edited XML
    
    scaleTool = ScaleTool(scaleXMLName);
    fprintf(['Scaling ' subjectName '...\n']);
    scaleTool.run(); % Execute the new scaling XML
    
    scaledModel = Model(outputModelName);
    scaledModel.initSystem(); % Load and initialize the new scaled model
    delete(scaleXMLName);

    for j = 1:length(subjectTRCTrials) % Loop through the trials

        %% IK
        kinematicsTool.setModel(scaledModel);

        % Get the name of the file for this trial
        markerFile = subjectTRCTrials{j};

        % Create name of trial from .trc file name
        trialName = regexprep(markerFile,'.trc','');

        % Get trc data to determine time range
        markerData = MarkerData(markerFile);

        % Get initial and intial time 
        initial_time = markerData.getStartFrameTime();
        final_time = markerData.getLastFrameTime();

        % Setup the kinematicsTool for this trial
        kinematicsTool.setName(trialName);
        kinematicsTool.setMarkerDataFileName(markerFile);
        kinematicsTool.setStartTime(initial_time);
        kinematicsTool.setEndTime(final_time);
        outputIK = [trialName '_ik.mot'];
        kinematicsTool.setOutputMotionFileName(outputIK);
        % Check for existing kinematics file
            allMOTs = dir('*.mot');
            if sum(contains({allMOTs.name}, outputIK)) == 1
                fprintf([trialName ' IK already completed' '\n']);
            else
                fprintf(['Performing IK on ' trialName '\n']);
                % Run IK
                kinematicsTool.run();
            end

        storage = Storage(outputIK);
        % 2. Check if it's currently in degrees
        if storage.isInDegrees()
            labels = storage.getColumnLabels(); 
            numCols = labels.getSize() - 1; % Subtract 1 for Time

            % 3. Loop through every row (time point)
            for k = 0:storage.getSize()-1
                stateVec = storage.getStateVector(k);
                data = stateVec.getData();

                % Loop through every column in that row
                for h = 0:numCols-1
                    label = char(labels.get(h+1)); % +1 because 0 is Time

                    % ONLY scale if it's NOT a translation (tx, ty, tz)
                    % This identifies rotations by looking for 'flexion', 'tilt', 'rotation', etc.
                    % Or more simply: anything NOT ending in 'tx', 'ty', 'tz'
                    if isempty(regexp(label, 't[xyz]$', 'once'))
                        currentVal = data.get(h);
                        data.set(h, currentVal * (pi/180));
                    end
                end
            end        
            % Ensure the internal flag is explicitly set to false
            storage.setInDegrees(false);
    
            % 3. Rename and save the "Radian" version
            storage.print(outputIK);
            fprintf('Converted %s to Radians\n', outputIK);
        end
        

        % Edit ExternalLoads xml
        xmlPath = fullfile(parentDirectory, "GRFLocalTemplate.xml"); % Read in template XML
        xmlFile = xmlread(xmlPath);
        grfName = [trialName '_GRF.mot'];
        xmlFile.getElementsByTagName('datafile').item(0).setTextContent(grfName);
        xmlFile.getElementsByTagName('data_source_name').item(0).setTextContent(grfName);
        xmlFile.getElementsByTagName('data_source_name').item(1).setTextContent(grfName);
        grfXMLName = [trialName '_GRF.xml'];
        xmlwrite(grfXMLName, xmlFile); % Save the edited XML


        %% ADJUST GRF COP LOCATIONS TO BE PROJECTED FROM THE HEEL MARKER POINTS
        % Get list of all .csv trials
        temp = strrep(trialName, [subjectName '_'], '');
        csvName = [temp '.csv'];
        data_read = readtable(csvName);
    
        currentMarkerSet = {};
    
        MOTtemplate = readcell(templateMOTname);
        
        csvData = readNoraxon(data_read, trajectoriesFixed, trajectoriesOriginal, forces);    
        dataCount = length(csvData.time);
        rotated_data = rotateAroundX(csvData, trajectoriesFixed);
        
        %% ROTATE AND TRANSLATE CENTER OF PRESSURE
        
        % Get rid of NaNs in CoP data
        [rotated_data.noNaN_CoP_LT_x, rotated_data.noNaN_CoP_LT_y, rotated_data.noNaN_GRF_LT] = fixCoPNaNs(rotated_data.Insole_LTInsole_CenterOfPressure_x_mm_, rotated_data.Insole_LTInsole_CenterOfPressure_y_mm_, rotated_data.LTInsole_Total___);
        [rotated_data.noNaN_CoP_RT_x, rotated_data.noNaN_CoP_RT_y, rotated_data.noNaN_GRF_RT] = fixCoPNaNs(rotated_data.Insole_RTInsole_CenterOfPressure_x_mm_, rotated_data.Insole_RTInsole_CenterOfPressure_y_mm_, rotated_data.RTInsole_Total___);
    
        % Convert from mm to m
        rotated_data.CoP_LT_y = repmat(-0.1, dataCount, 1);
        rotated_data.CoP_RT_y = repmat(-0.1, dataCount, 1);

        rotated_data.CoP_LT_x = (rotated_data.noNaN_CoP_LT_y + 2) / 1000;
        rotated_data.CoP_LT_z = rotated_data.noNaN_CoP_LT_x / 1000; 
        rotated_data.CoP_RT_x = (rotated_data.noNaN_CoP_RT_y - 2) / 1000;
        rotated_data.CoP_RT_z = rotated_data.noNaN_CoP_RT_x / 1000; 
        
        % CONVERT GRFS TO NEWTONS
        rotated_data.GRF_LT = (rotated_data.noNaN_GRF_LT ./ 100) .*subjectMass.*9.81;
        rotated_data.GRF_RT = (rotated_data.noNaN_GRF_RT ./ 100) .*subjectMass.*9.81;
        
        % CALCULATE GROUND REACTION MOMENTS
        rotated_data.M_LT_x = rotated_data.GRF_LT.*rotated_data.CoP_LT_z;
        % rotated_data.M_LT_y = 0;
        rotated_data.M_LT_z = rotated_data.GRF_LT.*rotated_data.CoP_LT_x;
        rotated_data.M_RT_x = rotated_data.GRF_RT.*rotated_data.CoP_RT_z;
        % rotated_data.M_RT_y = 0;
        rotated_data.M_RT_z = rotated_data.GRF_RT.*rotated_data.CoP_RT_x;

        % SET UP .MOT FILE
        % Set up header info
        trial_motName = append(trialName, '_GRF', '.mot');
    
        % Add specific header info
        MOTtemplate{1,1} = trial_motName;
        MOTtemplate{3,1} = append('nRows=',num2str(dataCount));
    
        % Add frame, time, and marker coordinate data
        for p = 1:dataCount
            MOTtemplate{p+7,1} = p*0.002-0.002; % Time
            MOTtemplate{p+7,2} = 0; % Left GRF x
            MOTtemplate{p+7,3} = rotated_data.GRF_LT(p); % Left GRF y
            MOTtemplate{p+7,4} = 0; % Left GRF z
            MOTtemplate{p+7,5} = rotated_data.CoP_LT_x(p); % Left CoP x
            MOTtemplate{p+7,6} = rotated_data.CoP_LT_y(p); % Left CoP y
            MOTtemplate{p+7,7} = rotated_data.CoP_LT_z(p); % Left CoP z
            %
            MOTtemplate{p+7,8} = 0; % Right GRF x
            MOTtemplate{p+7,9} = rotated_data.GRF_RT(p); % Right GRF y
            MOTtemplate{p+7,10} = 0; % Right GRF z
            MOTtemplate{p+7,11} = rotated_data.CoP_RT_x(p); % Right CoP x
            MOTtemplate{p+7,12} = rotated_data.CoP_RT_y(p); % Right CoP y
            MOTtemplate{p+7,13} = rotated_data.CoP_RT_z(p); % Right CoP z
            %
            MOTtemplate{p+7,14} = rotated_data.M_LT_x(p); % Left Moment x
            MOTtemplate{p+7,15} = 0; % Left Moment y
            MOTtemplate{p+7,16} = rotated_data.M_LT_z(p); % Left Moment z
            %
            MOTtemplate{p+7,17} = rotated_data.M_RT_x(p); % Right Moment x
            MOTtemplate{p+7,18} = 0; % Right Moment y
            MOTtemplate{p+7,19} = rotated_data.M_RT_z(p); % Right Moment z
        end
    
        % Remove <missing> in cells
        mask = cellfun(@(x) any(isa(x,'missing')), MOTtemplate);
        MOTtemplate(mask) = {[]};
    
        % WRITE GRF MOT FILE
        trial_fileName = trial_motName(1:end-4);
        fullfilePath = fullfile(trial_fileName);
        writecell(MOTtemplate, fullfilePath, 'Delimiter', '\t');
    
        % Change files from .txt to .mot
        file1 = append(fullfilePath, '.txt');
        file2 = strrep(file1,'.txt','.mot');
        copyfile(file1,file2);
        delete(file1);
        fprintf(['Wrote ' trial_fileName '.mot\n'])            

        %% ID
        kineticsTool.setModel(scaledModel);

        kineticsTool.setExternalLoadsFileName(grfXMLName);
        kineticsTool.setCoordinatesFileName(outputIK);

        % 4. Set Time Range and Output
        kineticsTool.setStartTime(initial_time);
        kineticsTool.setEndTime(final_time);
        outputID = [trialName '_ID.sto'];
        kineticsTool.setResultsDir(cd);
        outputIDpath = fullfile(cd, outputID);
        kineticsTool.setOutputGenForceFileName(outputIDpath);

        kineticsTool.setLowpassCutoffFrequency(6.0); % Filter data    

        fprintf(['Performing ID on ' trialName '\n']);
        kineticsTool.run();
    end
end